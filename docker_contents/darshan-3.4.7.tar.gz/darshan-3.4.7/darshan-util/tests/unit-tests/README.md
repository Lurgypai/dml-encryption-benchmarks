# Unit tests

This subdirectory contains unit tests cases that can be executed as part of
"make check" for the darshan-util directory

The tests in this subdirectory use munit to coordinate test cases, see
https://nemequ.github.io/munit/
