/*
 * Copyright (C) 2015 University of Chicago.
 * See COPYRIGHT notice in top-level directory.
 *
 */

#ifndef __DARSHAN_HEATMAP_LOGUTILS_H
#define __DARSHAN_HEATMAP_LOGUTILS_H

extern struct darshan_mod_logutil_funcs heatmap_logutils;

#endif
