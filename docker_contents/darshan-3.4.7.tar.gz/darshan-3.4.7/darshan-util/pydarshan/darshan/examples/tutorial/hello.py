#!/usr/bin/env python3

import darshan

r = darshan.DarshanReport("ior_hdf5_example.darshan")
r.info()
