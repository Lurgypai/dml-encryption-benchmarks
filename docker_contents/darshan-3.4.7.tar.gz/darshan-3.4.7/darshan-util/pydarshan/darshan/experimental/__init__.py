"""The experimental package provides some analysis functions for
aggregating darshan log data. The functions are not well
tested.
"""
