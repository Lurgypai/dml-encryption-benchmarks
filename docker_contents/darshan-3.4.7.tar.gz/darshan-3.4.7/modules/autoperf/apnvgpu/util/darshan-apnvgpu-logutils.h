/*
 * Copyright (C) 2018 University of Chicago.
 * See COPYRIGHT notice in top-level directory.
 *
 */

#ifndef __APNVGPU_LOG_UTILS_H
#define __APNVGPU_LOG_UTILS_H

extern char *apnvgpu_counter_names[];

extern struct darshan_mod_logutil_funcs apnvgpu_logutils;

#endif

