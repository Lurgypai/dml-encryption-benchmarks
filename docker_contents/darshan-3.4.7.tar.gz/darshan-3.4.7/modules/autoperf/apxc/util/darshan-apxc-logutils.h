/*
 * Copyright (C) 2018 University of Chicago.
 * See COPYRIGHT notice in top-level directory.
 *
 */

#ifndef __APXC_LOG_UTILS_H
#define __APXC_LOG_UTILS_H

extern char *apxc_counter_names[];

extern struct darshan_mod_logutil_funcs apxc_logutils;

#endif

