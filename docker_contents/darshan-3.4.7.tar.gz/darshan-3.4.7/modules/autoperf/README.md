AutoPerf is a module for Darshan which tracks compute and network metrics
on the Cray XC class systems.

OPEN SOURCE LICENSE