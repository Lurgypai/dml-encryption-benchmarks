/*
 * Copyright (C) 2018 University of Chicago.
 * See COPYRIGHT notice in top-level directory.
 *
 */

#ifndef __apss_LOG_UTILS_H
#define __apss_LOG_UTILS_H

extern char *apss_counter_names[];

extern struct darshan_mod_logutil_funcs apss_logutils;

#endif

